var searchData=
[
  ['_2enetcoreapp_2cversion_3dv3_2e1_2eassemblyattributes_2ecs_0',['.NETCoreApp,Version=v3.1.AssemblyAttributes.cs',['../_debug_2netcoreapp3_81_2_8_n_e_t_core_app_00_version_0av3_81_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../_release_2netcoreapp3_81_2_8_n_e_t_core_app_00_version_0av3_81_8_assembly_attributes_8cs.html',1,'(Global Namespace)']]]
];
