var searchData=
[
  ['select_21',['select',['../class_exericise2_1_1exericesnota.html#a2c15e7547201cba367fae994d38c9860',1,'Exericise2::exericesnota']]]
];
