var searchData=
[
  ['consoleapp7_2eassemblyinfo_2ecs_17',['ConsoleApp7.AssemblyInfo.cs',['../_debug_2netcoreapp3_81_2_console_app7_8_assembly_info_8cs.html',1,'(Global Namespace)'],['../_release_2netcoreapp3_81_2_console_app7_8_assembly_info_8cs.html',1,'(Global Namespace)']]]
];
