var indexSectionsWithContent =
{
  0: ".cemprs",
  1: "ep",
  2: "ce",
  3: ".cpr",
  4: "ms"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions"
};

