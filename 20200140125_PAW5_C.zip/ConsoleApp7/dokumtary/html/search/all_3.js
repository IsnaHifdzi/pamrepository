var searchData=
[
  ['menu_6',['menu',['../class_exericise2_1_1exericesnota.html#a154a8eb894c2ebb32f476b8d5e948ddd',1,'Exericise2::exericesnota']]]
];
